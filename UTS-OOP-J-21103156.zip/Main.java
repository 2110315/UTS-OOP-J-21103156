import java.util.Scanner;

public class Main {
    static Buku[] daftarBuku = new Buku[100];
    static int jumlahData = 0;
    static Scanner input = new Scanner(System.in);

    public static void main(String[] args) {
        int pilihan;
        do {
            System.out.println("\n=== Menu Perpustakaan ===");
            System.out.println("1. Tambah Buku");
            System.out.println("2. Tampilkan Buku");
            System.out.println("3. Ubah Buku");
            System.out.println("4. Hapus Buku");
            System.out.println("5. Keluar");
            System.out.print("Pilih: ");
            pilihan = input.nextInt();
            input.nextLine();

            switch (pilihan) {
                case 1: tambahBuku(); break;
                case 2: tampilkanBuku(); break;
                case 3: ubahBuku(); break;
                case 4: hapusBuku(); break;
            }
        } while (pilihan != 5);
    }

    static void tambahBuku() {
        System.out.print("Kode Buku    : ");
        String kode = input.nextLine();
        System.out.print("Judul Buku   : ");
        String judul = input.nextLine();
        System.out.print("Pengarang    : ");
        String pengarang = input.nextLine();
        System.out.print("Tahun Terbit : ");
        int tahun = input.nextInt();
        input.nextLine();

        daftarBuku[jumlahData] = new Buku(kode, judul, pengarang, tahun);
        jumlahData++;
        System.out.println("Buku berhasil ditambahkan!");
    }

    static void tampilkanBuku() {
        if (jumlahData == 0) {
            System.out.println("Belum ada buku.");
        } else {
            for (int i = 0; i < jumlahData; i++) {
                System.out.println("\nBuku ke-" + (i + 1));
                daftarBuku[i].tampilkanInfo();
            }
        }
    }

    static void ubahBuku() {
        System.out.print("Masukkan Kode Buku yang akan diubah: ");
        String kodeCari = input.nextLine();
        for (int i = 0; i < jumlahData; i++) {
            if (daftarBuku[i].getKodeBuku().equals(kodeCari)) {
                System.out.print("Judul baru     : ");
                daftarBuku[i].setJudul(input.nextLine());
                System.out.print("Pengarang baru : ");
                daftarBuku[i].setPengarang(input.nextLine());
                System.out.print("Tahun baru     : ");
                daftarBuku[i].setTahunTerbit(input.nextInt());
                input.nextLine();
                System.out.println("Buku berhasil diubah.");
                return;
            }
        }
        System.out.println("Buku tidak ditemukan.");
    }

    static void hapusBuku() {
        System.out.print("Masukkan Kode Buku yang akan dihapus: ");
        String kodeCari = input.nextLine();
        for (int i = 0; i < jumlahData; i++) {
            if (daftarBuku[i].getKodeBuku().equals(kodeCari)) {
                for (int j = i; j < jumlahData - 1; j++) {
                    daftarBuku[j] = daftarBuku[j + 1];
                }
                jumlahData--;
                System.out.println("Buku berhasil dihapus.");
                return;
            }
        }
        System.out.println("Buku tidak ditemukan.");
    }
}
