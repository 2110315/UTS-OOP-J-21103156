# UTS OOP - Aplikasi Perpustakaan

Aplikasi ini dibuat menggunakan Java untuk menyimpan data buku menggunakan array, serta menerapkan konsep OOP seperti class, constructor, overloading, overriding, access modifier, dan lain-lain.

## Fitur:
- Tambah data buku
- Tampilkan semua buku
- Ubah data buku berdasarkan kode
- Hapus data buku berdasarkan kode

## Struktur:
- Buku.java (Class buku)
- Main.java (Program utama)

## Petunjuk:
1. Compile kedua file menggunakan `javac Main.java Buku.java`
2. Jalankan program dengan `java Main`
